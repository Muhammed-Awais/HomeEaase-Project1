const { z } = require("zod");
const Property = require("../models/Property");

// ─────────────────────────────────────────────────────────────────────────────
// Lazy-loaded ESM imports (Vercel AI SDK is ESM-only)
// ─────────────────────────────────────────────────────────────────────────────

let _ai = null;
let _groqProvider = null;

async function getAI() {
  if (!_ai) {
    _ai = await import("ai");
  }
  return _ai;
}

async function getGroq() {
  if (!_groqProvider) {
    const mod = await import("@ai-sdk/groq");
    _groqProvider = mod.createGroq({ apiKey: process.env.GROQ_API_KEY });
  }
  return _groqProvider;
}

// ─────────────────────────────────────────────────────────────────────────────
// Database query helper
// ─────────────────────────────────────────────────────────────────────────────

const queryDatabase = async (filters) => {
  try {
    const query = {};

    if (filters.bedrooms) query.bedrooms = parseInt(filters.bedrooms);
    if (filters.city && filters.city.toLowerCase() !== "any") {
      query.city = new RegExp(filters.city, "i");
    }
    if (filters.furnishing) query.furnishing = new RegExp(filters.furnishing, "i");
    if (filters.floor) query.floor = new RegExp(filters.floor, "i");

    if (filters.maxPrice) {
      query.price = { $lte: parseInt(filters.maxPrice) };
    }
    if (filters.minPrice) {
      query.price = { ...(query.price || {}), $gte: parseInt(filters.minPrice) };
    }
    if (filters.type) {
      query.$or = [
        { type: new RegExp(filters.type, "i") },
        { title: new RegExp(filters.type, "i") }
      ];
    }

    // ── Structured diagnostics ──
    console.log("[DB Query]", JSON.stringify(query, (_k, v) => v instanceof RegExp ? v.toString() : v));

    const totalAll = await Property.countDocuments({});
    const totalFiltered = await Property.countDocuments(query);
    const totalAvailable = await Property.countDocuments({ ...query, isAvailable: true });

    console.log(`[DB Count] total_in_collection=${totalAll} | matches_filters=${totalFiltered} | matches_filters+isAvailable=${totalAvailable}`);

    // Use isAvailable filter only when it narrows results (guards against docs missing the field)
    const finalQuery = totalAvailable > 0 ? { ...query, isAvailable: true } : query;
    if (totalAvailable === 0 && totalFiltered > 0) {
      console.log("[DB Warn] isAvailable:true excluded all matches — querying without it");
    }

    const results = await Property.find(finalQuery).sort({ price: 1 }).limit(5).lean();
    console.log(`[DB Results] returning ${results.length} properties`);
    if (results.length > 0) {
      console.log("[DB Sample]", JSON.stringify({ _id: results[0]._id, title: results[0].title, city: results[0].city, type: results[0].type, isAvailable: results[0].isAvailable }));
    }
    return results;
  } catch (error) {
    console.error("[DB Error]", error.message);
    return [];
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// System Prompt
// ─────────────────────────────────────────────────────────────────────────────

const SYSTEM_PROMPT = `You are **HomeEase AI**, a friendly, intelligent, and highly conversational real estate assistant for the HomeEase property app in Pakistan. Your goal is to make the user feel like they are chatting with a real human agent.

### RULES:
1. **Scope**: You assist with property search, renting, listings, and real estate guidance in Pakistan on the HomeEase app.
2. **Conversational Tone**: Act like a warm, helpful human. Avoid robotic phrases like "I found X properties" or "They range from...". Instead, use natural language like "I'd love to help with that! I've pulled up a few great options for you," or "I've found some beautiful houses that might fit your needs."
3. **Engage the User**: If a user's request is too broad (e.g., "search house for me"), show the results but politely ask a follow-up question to narrow it down, like "Do you have a specific city or budget in mind?"
4. **Off-topic**: If the user asks anything unrelated to real estate, politely and smoothly guide them back.
5. **Tool Usage**: Call the searchProperties tool when the user wants to browse or find properties. Always call it if the user asks for a search, even if you did it recently. Once you get the tool result, write a natural, conversational reply introducing the results.
6. **No Results**: If there are no results, be empathetic. "I couldn't find any exact matches for that right now, but would you like to try a different location or adjust the budget?"
7. **Identity**: You are HomeEase AI. Do not mention AI models (Groq, LLaMA).
8. **Rent Only Platform**: HomeEase is strictly for RENTING. If they ask to buy, kindly explain that you specialize in rentals.
9. **Accuracy**: NEVER invent or hallucinate property details. Only discuss facts provided in the tool results.`;

// ─────────────────────────────────────────────────────────────────────────────
// Tool schema defined with Zod (required for correct Groq function calling)
// ─────────────────────────────────────────────────────────────────────────────

const searchPropertiesSchema = z.object({
  city: z.string().optional().describe("City name, e.g. Lahore, Karachi. Do not include this field if user says 'any city'."),
  bedrooms: z.number().optional().describe("Number of bedrooms. Include only if user explicitly asks for a specific number."),
  bathrooms: z.number().optional().describe("Number of bathrooms. Include only if explicitly requested."),
  budget: z.number().optional().describe("Maximum budget/price in PKR. Include only if user gives a max price."),
  minPrice: z.number().optional().describe("Minimum price in PKR. Include only if user gives a min price."),
  furnishing: z.string().optional().describe("Furnishing: furnished, semi-furnished, or unfurnished. Include only if specified."),
  type: z.string().optional().describe("Property type, e.g. flat, apartment, house, room, plot, shop. Include only if specified."),
});

// ─────────────────────────────────────────────────────────────────────────────
// Main chat processor
// ─────────────────────────────────────────────────────────────────────────────

const processChatMessage = async (message, history = []) => {
  try {
    const { generateText, tool, stepCountIs } = await getAI();
    const groq = await getGroq();

    const searchPropertiesTool = tool({
      description:
        "Search available property listings in the HomeEase database. Call this whenever the user wants to find, browse, or filter properties to rent or buy in Pakistan.",
      inputSchema: searchPropertiesSchema,
      execute: async (params) => {
        const filters = {};
        if (params.city) filters.city = params.city;
        if (params.bedrooms) filters.bedrooms = params.bedrooms;
        if (params.bathrooms) filters.bathrooms = params.bathrooms;
        if (params.budget) filters.maxPrice = params.budget;
        if (params.minPrice) filters.minPrice = params.minPrice;
        if (params.furnishing) filters.furnishing = params.furnishing;
        if (params.type) filters.type = params.type;

        console.log("[Tool Call] searchProperties:", JSON.stringify(filters));
        const results = await queryDatabase(filters);
        console.log(`[Tool Result] DB returned ${results.length} properties to AI`);

        if (results.length === 0) {
          return { found: 0, message: "No properties matched the criteria. Inform the user and stop.", results: [] };
        }

        const cleanResults = results.map((p) => ({
          _id: p._id?.toString(),
          id: p._id?.toString(),
          title: p.title,
          price: p.price,
          currency: p.currency || "PKR",
          city: p.city,
          location: p.location,
          propertyType: p.type,
          type: p.type,
          bedrooms: p.bedrooms,
          bathrooms: p.bathrooms,
          size: `${p.sizeValue} ${p.sizeUnit}`,
          furnishing: p.furnishing,
          purpose: p.purpose,
          amenities: p.amenities || [],
          images: p.images || [],
        }));

        return { found: results.length, results: cleanResults, instruction: "You now have the results. Write a brief text reply to the user. Do NOT call searchProperties again." };
      },
    });

    const messages = [
      ...history.map((h) => ({ role: h.role, content: h.content })),
      { role: "user", content: message },
    ];

    const result = await generateText({
      model: groq("llama-3.1-8b-instant"),
      system: SYSTEM_PROMPT,
      messages,
      tools: { searchProperties: searchPropertiesTool },
      stopWhen: stepCountIs(5),
      temperature: 0.4,
      maxTokens: 1024,
    });

    console.log("[AI Result] finishReason:", result.finishReason);
    console.log("[AI Result] text length:", result.text?.length || 0);
    console.log("[AI Result] steps:", result.steps?.length || 0);
    if (result.steps) {
      result.steps.forEach((step, i) => {
        console.log(
          `  Step ${i}: finishReason=${step.finishReason}, toolCalls=${step.toolCalls?.length || 0}, toolResults=${step.toolResults?.length || 0}, text="${step.text?.substring(0, 80) || ""}"`
        );
      });
    }

    // ── Extract listings from tool results ──
    // ai@6.x uses tc.input (not tc.args) and tr.output (not tr.result)
    let listings = [];
    let extractedFilters = {};

    if (result.steps) {
      for (const step of result.steps) {
        if (step.toolCalls) {
          for (const tc of step.toolCalls) {
            if (tc.toolName === "searchProperties") {
              const args = tc.input ?? tc.args ?? {};
              extractedFilters = { ...extractedFilters, ...args };
            }
          }
        }
        if (step.toolResults) {
          for (const tr of step.toolResults) {
            // ai@6.x: tr.output; older SDKs: tr.result
            const payload = tr.output ?? tr.result;
            if (payload && payload.results && payload.results.length > 0) {
              listings = payload.results;
            }
          }
        }
      }
    }

    console.log(`[Extract] listings=${listings.length}, filters=${JSON.stringify(extractedFilters)}, finishReason=${result.finishReason}`);

    let reply = result.text;

    if (!reply || reply.trim().length === 0) {
      if (listings.length > 0) {
        reply = `I found ${listings.length} propert${listings.length === 1 ? "y" : "ies"} matching your criteria.`;
      } else if (Object.keys(extractedFilters).length > 0) {
        reply = "No properties matched your criteria. Try adjusting your filters.";
      } else {
        reply = "I couldn't generate a response. Please try again.";
      }
    }

    return { reply, listings, filters: extractedFilters };
  } catch (error) {
    if (error.status === 429 || (error.message && error.message.includes("rate"))) {
      throw new Error("RATE_LIMIT_ERROR");
    }
    console.error("AI Service Error:", error);
    throw error;
  }
};

module.exports = { processChatMessage };
