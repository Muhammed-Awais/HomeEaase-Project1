import { Message, Notification, Property, StylePreset } from "./types";



export const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: "1",
    title: "New Property Match",
    body: "A 2-bedroom apartment in Gulberg matching your criteria has been listed.",
    type: "property",
    read: false,
    timestamp: "2 hours ago",
  },
  {
    id: "2",
    title: "Message from Ahmed Khan",
    body: "Hi, the apartment is available for viewing this weekend. Let me know!",
    type: "message",
    read: false,
    timestamp: "5 hours ago",
  },
  {
    id: "3",
    title: "Price Drop Alert",
    body: "The villa in DHA Phase 5 has reduced its rent by 10%.",
    type: "property",
    read: true,
    timestamp: "Yesterday",
  },
  {
    id: "4",
    title: "Welcome to Smart Rent!",
    body: "Start by chatting with our AI assistant or browse listings on your own.",
    type: "system",
    read: true,
    timestamp: "2 days ago",
  },
  {
    id: "5",
    title: "Listing Approved",
    body: 'Your property listing "Cozy Studio near Packages Mall" is now live.',
    type: "system",
    read: true,
    timestamp: "3 days ago",
  },
];

export const STYLE_PRESETS: StylePreset[] = [
  {
    id: "1",
    name: "Modern",
    emoji: "🏢",
    description: "Clean lines, neutral tones",
  },
  {
    id: "2",
    name: "Bohemian",
    emoji: "🌿",
    description: "Warm textures, earthy vibes",
  },
  {
    id: "3",
    name: "Minimalist",
    emoji: "⬜",
    description: "Less is more, open space",
  },
  {
    id: "4",
    name: "Industrial",
    emoji: "🏭",
    description: "Raw materials, exposed brick",
  },
  {
    id: "5",
    name: "Scandinavian",
    emoji: "🪵",
    description: "Light wood, cozy warmth",
  },
  {
    id: "6",
    name: "Art Deco",
    emoji: "✨",
    description: "Bold geometry, rich colors",
  },
];

export const SUGGESTION_CHIPS = [
  "2BHK in Lahore",
  "With parking",
  "Near university",
  "Furnished",
  "DHA Phase 5",
];

export const AMENITIES_LIST = [
  "WiFi",
  "Parking",
  "AC",
  "Kitchen",
  "Laundry",
  "Security",
  "Garden",
  "Pool",
  "Gym",
  "Elevator",
  "Terrace",
  "Servant Quarter",
  "Concierge",
  "Generator",
  "Water Supply",
];
